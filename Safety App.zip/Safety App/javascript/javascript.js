var button = document.querySelector("button");


button.addEventListener("click", function(){
	document.body.style.backgrounf = "purple";
});
